<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\loginController;
use App\Http\Controllers\registerController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\DataProdukController;
use App\Http\Controllers\DataPelangganController;
use App\Http\Controllers\UpdatePelangganController;
use App\Http\Controllers\UpdateProdukController;
use App\Http\Controllers\penjualanController;
use App\Http\Controllers\TambahProdukController;
use App\Http\Controllers\TambahPelangganController;
use App\Http\Controllers\DataPenjualanController;
use App\Http\Controllers\DetailPenjualanController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home'); // menampilkan file welcome.blade.php
});

//login route
Route::get('login', [LoginController::class, 'login'])->name('login');
Route::post('actionlogin', [LoginController::class, 'actionlogin'])->name('actionlogin');

//register route
Route::get('register', [registerController::class, 'register'])->name('register');
Route::post('register/action', [registerController::class, 'actionregister'])->name('actionregister');


//tampil data route
//Route::get('/DataPelanggan', [DataPelangganController::class, 'DataPelanggan'])->name('DataPelanggan')->middleware('auth');
Route::get('/DataPelanggan', [DataPelangganController::class, 'DataPelanggan']);
Route::post('/tambahpelanggan', [DataPelangganController::class, 'store'])->name('tambahpelanggan');
//Route::post('data/simpan', [DataPelangganController::class, 'DataPelanggan'])->name('simpansantri')->middleware('auth');


//Route::get('/DataProduk', [DataProdukController::class, 'DataProduk']);
Route::get('/DataProduk', [DataProdukController::class, 'DataProduk']);
Route::post('/TambahProduk', [DataProdukController::class, 'store'])->name('TambahProduk');
Route::get('/TambahProduk', [DataProdukController::class, 'TambahProduk'])->name('TambahProduk');
Route::delete('/HapusProduk', [DataProdukController::class, 'destroy'])->name('HapusProduk');
//Route::get('/TambahProduk', [DataProdukController::class, 'Store'])->name('TambahProduk');
//Route::get('TambahPelanggan', [DataProduk::class, 'DataPelanggan'])->name('tambahpelanggan')->middleware('auth');
//Route::post('data/simpan', [DataProduk::class, 'DataPelanggan'])->name('simpanpelanggan')->middleware('auth');
//

Route::get('/UpdatePelanggan', [UpdatePelangganController::class, 'UpdatePelanggan']);

Route::get('/UpdateProduk', [UpdateProdukController::class, 'updateProduk']);

Route::get('/penjualan', [penjualanController::class, 'penjualan']);

Route::get('/TambahPelanggan', [TambahPelangganController::class, 'TambahPelanggan']);

Route::get('/DataPenjualan', [DataPenjualanController::class, 'DataPenjualan']);

Route::get('/DetailPenjulan', [DetailPenjualanController::class, 'DetailPenjualan']);