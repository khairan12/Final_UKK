@include('layout.link')
@section('konten')
<h3>Tampil Data </h3>
<a class="btn btn-success" href="/TambahPelanggan"><i class="fa fa-plus"></i> tambah data</a><br><br>
<table class="table table-bordered table-hover">
  <tr>
    <th>PelangganID</th>
    <th>Nama Pelanggan</th>
    <th>Alamat</th>
    <th>Nomor Telepon</th>
    <th>aksi</th>
  </tr>
  @foreach($pelanggan as $pelanggan) 
  <tr>
    <td>{{$pelanggan->PelangganID}}</td>
    <td>{{$pelanggan->NamaPelanggan}}</td>
    <td>{{$pelanggan->Alamat}}</td>
    <td>{{$pelanggan->NomorTelepon}}</td>
    
    <td>
      <a href="/TambahPelanggan/{{$pelanggan->PelangganID}}" class="btn btn-warning btn-sm"><i class="fa fa-pencil">edit</i></a>
      <a href="/data/hapus/{{$pelanggan->PelangganID}}" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm" >hapus<i class="fa fa-trash"></i></a>
    </td>
  </tr>
  @endforeach
</table>

