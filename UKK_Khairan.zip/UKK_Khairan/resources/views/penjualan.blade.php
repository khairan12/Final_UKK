<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<body>

<div class="info">
  @if(session("info"))
</div class="info">{{session("info")}}</div>
@endif
    <br>
    <br>
    <center><h1>Data Produk</h1></center>
    <br>
    @method('POST')
      @CSRF
    <form>
        <div class="container">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Data Produk</label>
    <select class="form-select" aria-label="Default select example">
    @foreach($produk as $produk)
      <option value="{{ $produk->ProdukID }}">{{ $produk->NamaProduk }}</option>
    @endforeach
  <option selected></option>
  <option value="1"></option>
  <option value="2"></option>
  <option value="3"></option>
</select>
  </div>    
  <div class="container">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Jumlah Produk</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text"></div>
  </div>
  </div>
  <div class="container"><button type="button" class="btn btn-success">Tambah</button></div>  
  <br>
  <br>
  <br>
  <br> 
  <div class="container">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nama Pelanggan</label>
    <select class="form-select" aria-label="Default select example">
  <option selected>
  </option>
  <option value="1"></option>
  <option value="2"></option>
  <option value="3"></option>
</select>
  </div>
  </div>
  <br>
  <br>
  <div class="container">
  <table class="table">
  <thead>
    <tr>
      <th scope="col">Produk ID</th>
      <th scope="col">Nama Produk</th>
      <th scope="col">Harga</th>
      <th scope="col">Stok</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <?php $total_harga = 0?>
    @foreach($detailpenjualan as $detailpenjualan)
    <tr>
      <th scope="row"></th>
      <td><center>{{ $detailpenjualan->NamaProduk }}</center></td>
      <td><center>Rp. {{ number_format($detailpenjualan->Harga)}}</center></td>
      <td><center>{{ $detailpenjualan->jumlahproduk }}</center></td>
      <td><center>Rp. {{ number-format($detailpenjualan->SubTotal) }}</center></td>
      <td><center>
        <a href="/pelanggan/{{$pelanggan->pelangganID}}" type="button" class="btn btn-outline-danger"><i class="fa-solid fa-trash"></i></a>
      </center></td>
    <?php $total_harga = $total_harga + $detailpenjualan->subtotal?>
      <td><button type="button" class="btn btn-danger"></button></td>
    </tr>
    @endforeach
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
      <td><button type="button" class="btn btn-danger"></button></td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2"></td>
      <td></td>
      <td><button type="button" class="btn btn-danger"></button></td>
    </tr>
  </tbody>
</table>
</div>
<br>
<div class="container"><h1></h1></div>
<br>
<div class="container"><button type="button" class="btn btn-info"></button></div>
</form>

<div class ="card mt-3">
<div class="card-body">
<h1>Total Harga : {{ number_format($total_harga,0, ',' , '.')}}</h1>
</div>
<form class="d-grid gap-2 mt-3" action="{{url("/checkout")}}" method="POST"></form>
@method("POST")
@CSRF

<input class="btn btn-primary" type="submit" name="submit" value="Checkout">
</div>
</body>
</html>