@include('layout.link')
@section('konten')
<h3>Tampil Data </h3>
<a class="btn btn-success" href="/TambahProduk"><i class="fa fa-plus"></i> tambah data</a><br><br>
<table class="table table-bordered table-hover">
  <tr>
    <th>Produk ID</th>
    <th>Nama Produk</th>
    <th>harga</th>
    <th>Stok</th>
    <th>aksi</th>
  </tr>
  @foreach($produk as $produk) 
  <tr>
    <td>{{$produk->ProdukID}}</td>
    <td>{{$produk->NamaProduk}}</td>
    <td>{{$produk->Harga}}</td>
    <td>{{$produk->Stok}}</td>
    
    <td>
      <a href="/TambahProduk/{{$produk->ProdukID}}" class="btn btn-warning btn-sm"><i class="fa fa-pencil">edit</i></a>
      <a href="/HapusProduk/{{$produk->ProdukID}}" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm" >hapus<i class="fa fa-trash"></i></a>
    </td>
  </tr>
  @endforeach
</table>