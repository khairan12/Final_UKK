<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
</head>
<body>

<form method="POST" action="{{ url('TambahProduk') }}">
@csrf  
<br>
  <br>
<br>
    <center><h1>Tambah Produk</h1></center>
   
    <div class="container"><div class="mb-3">
  
  <label for="exampleFormControlInput1" class="form-label">Nama Produk</label>
  <input type="text" class="form-control" id="exampleFormControlInput1" name="NamaProduk">
  
  @error('title')
    <div class="alert alert-danger mt-2">
    {{ $message }}
    </div>
    @enderror
    </div>

</div>
</div>
<div class="container"><div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Harga</label>
  <input type="number" class="form-control" id="exampleFormControlInput1" name="Harga">

  @error('title')
    <div class="alert alert-danger mt-2">
    {{ $message }}
    </div>
    @enderror
    </div>

</div>
</div>
<div class="container"><div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Stok</label>
  <input type="number" class="form-control" id="exampleFormControlInput1" name="Stok">

  @error('title')
    <div class="alert alert-danger mt-2">
    {{ $message }}
    </div>
    @enderror
    </div>

  <br>
  <div class="d-grid gap-2 d-md-flex justify-content-md-end">
  <button type="submit" class="btn btn-primary me-md-2" type="button">Tambah

  
  </button>
</div>
</body>
</html>