<?php echo $__env->make('layout.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('konten'); ?>
<h3>Tampil Data </h3>
<a class="btn btn-success" href="/TambahPelanggan"><i class="fa fa-plus"></i> tambah data</a><br><br>
<table class="table table-bordered table-hover">
  <tr>
    <th>PelangganID</th>
    <th>Nama Pelanggan</th>
    <th>Alamat</th>
    <th>Nomor Telepon</th>
    <th>aksi</th>
  </tr>
  <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
  <tr>
    <td><?php echo e($pelanggan->PelangganID); ?></td>
    <td><?php echo e($pelanggan->NamaPelanggan); ?></td>
    <td><?php echo e($pelanggan->Alamat); ?></td>
    <td><?php echo e($pelanggan->NomorTelepon); ?></td>
    
    <td>
      <a href="/TambahPelanggan/<?php echo e($pelanggan->PelangganID); ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil">edit</i></a>
      <a href="/data/hapus/<?php echo e($pelanggan->PelangganID); ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Data?');" class="btn btn-danger btn-sm" >hapus<i class="fa fa-trash"></i></a>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php /**PATH C:\xampp\htdocs\UKK_Khairan\resources\views/DataPelanggan.blade.php ENDPATH**/ ?>