<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
</head>
<body>

<form method="POST" action="<?php echo e(url('TambahProduk')); ?>">
<?php echo csrf_field(); ?>  
<br>
  <br>
<br>
    <center><h1>Tambah Produk</h1></center>
   
    <div class="container"><div class="mb-3">
  
  <label for="exampleFormControlInput1" class="form-label">Nama Produk</label>
  <input type="text" class="form-control" id="exampleFormControlInput1" name="NamaProduk">
  
  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mt-2">
    <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>
</div>
<div class="container"><div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Harga</label>
  <input type="number" class="form-control" id="exampleFormControlInput1" name="Harga">

  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mt-2">
    <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>
</div>
<div class="container"><div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Stok</label>
  <input type="number" class="form-control" id="exampleFormControlInput1" name="Stok">

  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mt-2">
    <?php echo e($message); ?>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

  <br>
  <div class="d-grid gap-2 d-md-flex justify-content-md-end">
  <button type="submit" class="btn btn-primary me-md-2" type="button">Tambah

  
  </button>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\UKK_Khairan\resources\views/TambahProduk.blade.php ENDPATH**/ ?>