<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>
</nav>
<nav class="navbar" style="background-color: #F5CCA0;">
  <div class="container-fluid">
  <span class="navbar-brand mb-0 h1 text-center"><i class="fa-solid fa-bowl-food"></i> Warung Nopul</span>
    <ul class="nav justify-content-end">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Data Produk</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
</ul>
  </div>
</nav>
<br>
    <center><h1>Data Penjualan</h1></center>
    <div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">Tanggal</th>
      <th scope="col">Pelanggan</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <th scope="row">2-12-2023</th>
      <td>Faiz</td>
      <td>Rp. 25.000</td>
      <td><button type="button" class="btn btn-info">Detail</button></td>
</tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\UKK_Khairan\resources\views/DataPenjualan.blade.php ENDPATH**/ ?>