<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\PelangganModel;
use Illuminate\Support\Facades\DB;

class DataPelangganController extends Controller
{
    public function DataPelanggan()
    {
        $pelanggan = PelangganModel::select('*')->get();
                
        return view('DataPelanggan', ['pelanggan' => $pelanggan]);
    }

    public function BuatDataPelanggan()
    {
        return view('BuatDataPelanggan');
    }

         public function create(): View
         {
             return view('TambahPelanggan');
         }

        /**
         * store
         *
         * @param  mixed $request
         * @return RedirectResponse
         */
        public function store(Request $request)
        {

          
            //validate form
            $this->validate($request, [
                //'image'     => 'required|image|mimes:jpeg,jpg,png|max:2048',
                'NamaPelanggan'     => 'required',
                'Alamat'   => 'required',
                'NomorTelepon'  => 'required',
            ]);


            //create post
            DB::table('pelanggan')->insert([
                //'image'     => $image->hashName(),
                'PelangganID'     => $request->PelangganID,
                'NamaPelanggan'   => $request->NamaPelanggan,
                'Alamat' => $request->Alamat,
                'NomorTelepon' => $request->NomorTelepon,
            ]);

            //redirect to index
            //return redirect()->back()->with(['success' => 'Data Berhasil Disimpan!']);
            return redirect('/DataPelanggan');
        }

    public function destroy($id): RedirectResponse
    {
        //get post by ID
        $post = Post::findOrFail($id);


        //delete post
        $post->delete();

        //redirect to index
        return redirect()->route('DataPelanggan')->with(['success' => 'Data Berhasil Dihapus!']);
    }


    // public function tambahsantri()
    // {
    //     return view('tambahsantri');
    // }

    // public function simpansantri(Request $request)
    // {
    //     $pelanggan = PelangganModel::create([
    //         'PelangganID' => $request->PelangganID,
    //         'NamaPelanggan' => $request->NamaPelanggan,
    //         'Alamat' => $request->Alamat,
    //         'NomorTelepon' => $request->NomorTelepon,
            
    //     ]);

    //     return redirect()->route('DataPelanggan');
    // }
}