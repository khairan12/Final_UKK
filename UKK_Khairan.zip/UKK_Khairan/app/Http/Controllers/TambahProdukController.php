<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TambahProdukController extends Controller
{
    function TambahProduk(){
        return view("TambahProduk");
    }
}
