<?php

namespace App\Http\Controllers;
use App\Models\Post;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class BuatDataPelangganController extends Controller


{
    public function create(): View
    {
        return view('posts.create');
    }    

    
}
