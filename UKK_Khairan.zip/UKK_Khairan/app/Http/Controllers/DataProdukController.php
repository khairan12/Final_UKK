<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProdukModel;
use Illuminate\Support\Facades\DB;
class DataProdukController extends Controller
{
    public function DataProduk()
    {
        $produk = produkModel::select('*')->get();
                
        return view('DataProduk', ['produk' => $produk]);
    }

    public function TambahProduk(){
        return view("TambahProduk");
    }

    public function store(Request $request)
        {

          
            //validate form
            $this->validate($request, [
                //'image'     => 'required|image|mimes:jpeg,jpg,png|max:2048',
                'NamaProduk'     => 'required',
                'Harga'   => 'required',
                'Stok'  => 'required',
            ]);


            //create post
            DB::table('produk')->insert([
                //'image'     => $image->hashName(),
                'ProdukID'     => $request->ProdukID,
                'NamaProduk'   => $request->NamaProduk,
                'Harga' => $request->Harga,
                'Stok' => $request->Stok,
            ]);

            //redirect to index
            //return redirect()->back()->with(['success' => 'Data Berhasil Disimpan!']);
            return redirect('DataProduk');
            
        }
        public function destroy($produk): RedirectResponse
        {
            //get post by ID
            $post = Post::findOrFail($produk);
    
    
            //delete post
            $post->delete();
    
            //redirect to index
            return redirect()->route('HapusProduk')->with(['success' => 'Data Berhasil Dihapus!']);
        }
}
