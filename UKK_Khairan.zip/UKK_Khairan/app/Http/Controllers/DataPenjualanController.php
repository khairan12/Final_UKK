<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DataPenjualanController extends Controller
{
    function DataPenjualan(){
        return view("DataPenjualan");
    }
}
