<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TambahPelangganController extends Controller
{
    function TambahPelanggan(){
        return view("TambahPelanggan");
    }
    
}
