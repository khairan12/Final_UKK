<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PenjualanController extends Controller
{
    
    function Penjualan(){
        $produk = DB::table("produk")->get();
        $pelanggan = DB::table("pelanggan")->get();
        $penjualan = DB::table("penjualan")->latest()->first();
        $PenjualanID = "";
        
        if (!$penjualan){
            $PenjualanID = '1';
        }
        else{
            $PenjualanID = $penjualan->PenjualanID;
        }

        $detailpenjualan=DB::table("detailpenjualan")->where ("PenjualanID", $PenjualanID)
        ->join ("produk", "detailpenjualan.produkID", "=", 'produk.produkID')
        ->get();
    
        return view("penjualan", [
            'detailpenjualan' => $detailpenjualan,
            'PenjualanID' => $PenjualanID,
            'produk' => $produk,
            'pelanggan' => $pelanggan
        ]);
    }
      function store(Request $request){

        $produk = DB::table('produk')->where('produkID', $request->produk)->first();

        $DataPenjualan = DB::table('penjualan')->where('PenjualanID', $request->IDpenjualan)->first();
        if(!$DataPenjualan){
        
            $penjualan = DB::table ("penjualan")->Insert([
            'PenjualanID'=> $request->idpenjualan,
            'tanggalpenjualan' => date ("Y-m-d"),
            'TotalHarga' => 0,
            'pelangganID' => $request->idpelanggan
        ]);
    }
        //  function store(Request $request)
        //  $produk = DB::table('produk')->where('ProdukID', $request->produk)->first();
        //  $Datapenjualan=DB::table('produk')->where('penjualanID', $request->idpenjualan)->first();
        //  if(!DataPenjualan){

        //  $penjualan = DB::table("detailpenjualan")->insert([
        //      'penjualanID' => $request->idPenjualan,
        //      'tanggalpenjualan' => date("Y-m-d"),
        //      'Totalharga' => 0,
        //      'pelangganid' => $request->pelanggan,
         
        // ]);
    
        $detailpenjualan = DB::table ("detailpenjualan") ->Insert([
            'PenjualanID' => $request->idpenjualan,
            "produkID" => $request->produk,
            'jumlahproduk' => $request->qty,
            'subtotal' => $request->qty * $produk->Harga
        ]);

        DB::table("produk")->where('produkID', $request->produk)->update(['stok' => $produk->stok
        - $request->jumlah]);
        
        return redirect()->back();
    } 
    function checkout(Request $request){
        $updateData = DB::table('penjualan')->where('PenjualanID', '=', $request->PenjualanID)
        ->update([
            'status' => 'selesai',
            'TotalHarga' => $request->totalHarga
        ]);
   
        if($updateData){
            return redirect()->back()->with('info' , "penjualan telah berhasil");
        }
    }
     
}
