<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UpdatePelangganController extends Controller
{
    function UpdatePelanggan(){
        return view("UpdatePelanggan");
    }
}
