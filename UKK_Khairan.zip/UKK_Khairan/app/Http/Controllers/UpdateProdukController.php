<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UpdateProdukController extends Controller
{
    function updateProduk(){
        return view("UpdateProduk");
    }
}
